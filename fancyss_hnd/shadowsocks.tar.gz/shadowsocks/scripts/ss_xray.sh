#!/bin/sh

# shadowsocks script for HND/AXHND router with kernel 4.1.27/4.1.51 merlin firmware

source /koolshare/scripts/base.sh
eval $(dbus export ss_basic_)
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'
XRAY_CONFIG_FILE="/koolshare/ss/xray.json"
url_main="https://raw.githubusercontent.com/Auroraxpm/fancyss/master/xray_binary"
url_back=""

get_latest_version(){
	rm -rf /tmp/xray_latest_info.txt
	echo_date "检测XRay最新版本..."
	curl --connect-timeout 8 -s $url_main/latest.txt > /tmp/xray_latest_info.txt
	if [ "$?" == "0" ];then
		if [ -z "`cat /tmp/xray_latest_info.txt`" ];then
			echo_date "获取XRay最新版本信息失败！使用备用服务器检测！"
			failed_warning_xray
		fi
		if [ -n "`cat /tmp/xray_latest_info.txt|grep "404"`" ];then
			echo_date "获取XRay最新版本信息失败！使用备用服务器检测！"
			failed_warning_xray
		fi
		V2VERSION=`cat /tmp/xray_latest_info.txt | sed 's/v//g'` || 0
		echo_date "检测到XRay最新版本：v$V2VERSION"
		if [ ! -f "/koolshare/bin/xray"  ];then
			echo_date "Xray安装文件丢失！重新下载！"
			CUR_VER="0"
		else
			CUR_VER=`xray -version 2>/dev/null | head -n 1 | cut -d " " -f2 | sed 's/v//g'` || 0
			echo_date "当前已安装XRay版本：v$CUR_VER"
		fi
		COMP=`versioncmp $CUR_VER $V2VERSION`
		if [ "$COMP" == "1" ];then
			[ "$CUR_VER" != "0" ] && echo_date "XRay已安装版本号低于最新版本，开始更新程序..."
			update_now v$V2VERSION
		else
			XRAY_LOCAL_VER=`/koolshare/bin/xray -version 2>/dev/null | head -n 1 | cut -d " " -f2`
			XRAY_LOCAL_DATE=`/koolshare/bin/xray -version 2>/dev/null | head -n 1 | cut -d " " -f4`
			[ -n "$XRAY_LOCAL_VER" ] && dbus set ss_basic_xray_version="$XRAY_LOCAL_VER"
			[ -n "$XRAY_LOCAL_DATE" ] && dbus set ss_basic_xray_date="$XRAY_LOCAL_DATE"
			echo_date "XRay已安装版本已经是最新，退出更新程序!"
		fi
	else
		echo_date "获取XRay最新版本信息失败！使用备用服务器检测！"
		failed_warning_xray
	fi
}

failed_warning_xray(){
	echo_date "获取XRay最新版本信息失败！请检查到你的网络！"
	echo_date "==================================================================="
	echo XU6J03M6
	exit 1
}

update_now(){
	rm -rf /tmp/xray
	mkdir -p /tmp/xray && cd /tmp/xray

	echo_date "开始下载校验文件：md5sum.txt"
	wget --no-check-certificate --timeout=20 -qO - $url_main/$1/md5sum.txt > /tmp/xray/md5sum.txt
	if [ "$?" != "0" ];then
		echo_date "md5sum.txt下载失败！"
		md5sum_ok=0
	else
		md5sum_ok=1
		echo_date "md5sum.txt下载成功..."
	fi
	
	echo_date "开始下载xray程序"
	wget --no-check-certificate --timeout=20 --tries=1 $url_main/$1/xray
	#curl -L -H "Cache-Control: no-cache" -o /tmp/xray/xray $url_main/$1/xray
	if [ "$?" != "0" ];then
		echo_date "xray下载失败！"
		xray_ok=0
	else
		xray_ok=1
		echo_date "xray程序下载成功..."
	fi



	if [ "$md5sum_ok=1" ] && [ "$xray_ok=1" ] ;then
		check_md5sum
	else
		echo_date "使用备用服务器下载..."
		echo_date "下载失败，请检查你的网络！"
		echo_date "==================================================================="
		echo XU6J03M6
		exit 1
	fi
}

check_md5sum(){
	cd /tmp/xray
	echo_date "校验下载的文件!"
	XRAY_LOCAL_MD5=`md5sum xray|awk '{print $1}'`
	XRAY_ONLINE_MD5=`cat md5sum.txt|grep -w xray|awk '{print $1}'`
	
	if [ "$XRAY_LOCAL_MD5"x = "$XRAY_ONLINE_MD5"x ] ;then
		echo_date "文件校验通过!"
		install_binary
	else
		echo_date "校验未通过，可能是下载过程出现了什么问题，请检查你的网络！"
		echo_date "==================================================================="
		echo XU6J03M6
		exit 1
	fi
}

install_binary(){
	echo_date "开始覆盖最新二进制!"
	if [ "`pidof xray`" ];then
		echo_date "为了保证更新正确，先关闭xray主进程... "
		killall xray >/dev/null 2>&1
		move_binary
		sleep 1
		start_xray
	else
		move_binary
	fi
}

move_binary(){
	echo_date "开始替换xray二进制文件... "
	mv /tmp/xray/xray /koolshare/bin/xray
	
	chmod +x /koolshare/bin/xray*
	XRAY_LOCAL_VER=`/koolshare/bin/xray -version 2>/dev/null | head -n 1 | cut -d " " -f2`
	XRAY_LOCAL_DATE=`/koolshare/bin/xray -version 2>/dev/null | head -n 1 | cut -d " " -f5`
	[ -n "$XRAY_LOCAL_VER" ] && dbus set ss_basic_xray_version="$XRAY_LOCAL_VER"
	[ -n "$XRAY_LOCAL_DATE" ] && dbus set ss_basic_xray_date="$XRAY_LOCAL_DATE"
	echo_date "xray二进制文件替换成功... "
}

start_xray(){
	echo_date "开启xray进程... "
	cd /koolshare/bin
	export GOGC=30
	xray --config=/koolshare/ss/xray.json >/dev/null 2>&1 &
	
	local i=10
	until [ -n "$V2PID" ]
	do
		i=$(($i-1))
		V2PID=`pidof xray`
		if [ "$i" -lt 1 ];then
			echo_date "xray进程启动失败！"
			close_in_five
		fi
		sleep 1
	done
	echo_date xray启动成功，pid：$V2PID
}

case $2 in
1)
	echo " " > /tmp/upload/ss_log.txt
	http_response "$1"
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	echo_date "                xray程序更新(Shell by sadog)" >> /tmp/upload/ss_log.txt
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	get_latest_version >> /tmp/upload/ss_log.txt 2>&1
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	echo XU6J03M6 >> /tmp/upload/ss_log.txt
	;;
esac