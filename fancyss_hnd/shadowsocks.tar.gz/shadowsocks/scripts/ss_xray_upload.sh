#!/bin/sh

# shadowsocks script for HND/AXHND router with kernel 4.1.27/4.1.51 merlin firmware

source /koolshare/scripts/base.sh
eval $(dbus export ss_basic_)
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'
V2RAY_CONFIG_FILE="/koolshare/ss/v2ray.json"
upload_path=/tmp/upload
upload_file=/tmp/upload/xray

local_binary_replace(){
	chmod +x $upload_file
	xray_upload_ver=$($upload_file -version 2>/dev/null | head -n 1 | cut -d " " -f2)
	if [ -n "$xray_upload_ver" ]; then
		echo_date "上传xray二进制版本为：$xray_upload_ver" >> /tmp/upload/ss_log.txt
		echo_date "开始替换处理" >> /tmp/upload/ss_log.txt
		replace_binary
	else
		echo_date "上传的二进制不合法！！！" >> /tmp/upload/ss_log.txt
		rm -rf /tmp/upload/xray
	fi
}
replace_binary(){
	echo_date "检查空间" >> /tmp/upload/ss_log.txt
	SPACE_AVAL=$(df|grep jffs | awk '{print $4}')
	SPACE_NEED=$(du -s /tmp/upload/xray | awk '{print $1}')
	if [ "$SPACE_AVAL" -gt "$SPACE_NEED" ];then
		echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 二进制需要"$SPACE_NEED" KB，空间满足，继续安装！ >> /tmp/upload/ss_log.txt
		echo_date "开始替换xray二进制!" >> /tmp/upload/ss_log.txt
		if [ "$(pidof xray)" ];then
			echo_date "为了保证更新正确，先关闭clash主进程... " >> /tmp/upload/ss_log.txt
			killall xray >/dev/null 2>&1
			move_binary
			sleep 1
			start_xray
		else
			move_binary
		fi
	else
		echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 二进制需要"$SPACE_NEED" KB，空间不足！ >> /tmp/upload/ss_log.txt
		echo_date 退出安装！ >> /tmp/upload/ss_log.txt
		echo XU6J03M6 >> /tmp/upload/ss_log.txt
		rm -rf /tmp/upload/xray
		exit 1
	fi
}

move_binary(){
	echo_date "开始替换xray二进制文件... " >> /tmp/upload/ss_log.txt
	mv $upload_file /koolshare/bin/xray
	chmod +x /koolshare/bin/xray
	V2RAY_LOCAL_VER=`/koolshare/bin/xray -version 2>/dev/null | head -n 1 | cut -d " " -f2`
	[ -n "$V2RAY_LOCAL_VER" ] && dbus set ss_basic_v2ray_version="$V2RAY_LOCAL_VER"
	echo_date "v2ray二进制文件替换成功... "
}

start_xray(){
	echo_date "开启xray进程... "
	cd /koolshare/bin
	export GOGC=30
	xray --config=/koolshare/ss/v2ray.json >/dev/null 2>&1 &
	
	local i=10
	until [ -n "$V2PID" ]
	do
		i=$(($i-1))
		V2PID=`pidof xray`
		if [ "$i" -lt 1 ];then
			echo_date "xray进程启动失败！"
			close_in_five
		fi
		sleep 1
	done
	echo_date xray启动成功，pid：$V2PID
	
}

close_in_five() {
	echo_date "插件将在5秒后自动关闭！！"
	local i=5
	while [ $i -ge 0 ]; do
		sleep 1
		echo_date $i
		let i--
	done
	dbus set ss_basic_enable="0"
	sh /koolshare/ss/ssconfig.sh stop
}

case $2 in
20)
	echo " " > /tmp/upload/ss_log.txt
	http_response "$1"
	echo "本地上传xray二进制替换" >> /tmp/upload/ss_log.txt
	local_binary_replace >> /tmp/upload/ss_log.txt 2>&1
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	echo XU6J03M6 >> /tmp/upload/ss_log.txt
	;;
esac