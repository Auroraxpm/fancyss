#!/bin/sh

# shadowsocks script for HND/AXHND router with kernel 4.1.27/4.1.51 merlin firmware

#source /koolshare/scripts/ss_base.sh
#-----------------------------------------------
# Variable definitions
export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
source helper.sh
#eval `dbus export ss`

dbus set ss_basic_version_local=$(cat /koolshare/ss/version)
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/upload/ss_log.txt
V2RAY_CONFIG_FILE_TMP="/tmp/v2ray_tmp.json"
V2RAY_CONFIG_FILE="/koolshare/ss/v2ray.json"


close_in_five() {
	echo_date "插件将在5秒后自动关闭！！" >> $LOG_FILE
	local i=5
	while [ $i -ge 0 ]; do
		sleep 1
		echo_date $i
		let i--
	done
	dbus set ss_basic_enable="0"

	sh /koolshare/ss/ssconfig.sh stop
	echo XU6J03M6 >> /tmp/upload/ss_log.txt
	exit
}

check2(){
	sh /tmp/upload/t1.sh 
}
check(){
	echo_date 测试V2Ray配置文件.....  >> $LOG_FILE	
	cd /koolshare/bin

	v2ctl config /koolshare/ss/v2ray.json > /koolshare/ss/v2ray.pb
	sleep 3s
	if [ -s /koolshare/ss/v2ray.pb ] ; then
		echo_date  "【v2ray】" "♥️ v2ray配置文件json已转为pb格式..." >> $LOG_FILE	
		start
	else
		echo_date "【v2ray】" "✘转换json配置文件为pb格式失败，v2s.pb文件为空。"  >> $LOG_FILE	
		close_in_five
	fi
}

start(){
	if [ "$ss_basic_tfo" == "1" ]; then
		echo_date 开启tcp fast open支持. >> $LOG_FILE
		echo 3 >/proc/sys/net/ipv4/tcp_fastopen
	fi

	echo_date "开启v2ray进程... " >> $LOG_FILE	
	cd /koolshare/bin
	#export GOGC=30
	#v2ray --config=/koolshare/ss/v2ray.json >/dev/null 2>&1 &
	v2ray -format=pb -config=/koolshare/ss/v2ray.pb >/dev/null 2>&1 &
	local i=10
	until [ -n "$V2PID" ]
	do
		i=$(($i-1))
		V2PID=`pidof v2ray`
		if [ "$i" -lt 1 ];then
			echo_date "v2ray进程启动失败！" >> $LOG_FILE	
			close_in_five
		fi
		sleep 1
	done
	echo_date v2ray启动成功，pid：$V2PID >> $LOG_FILE	

	BIN=v2ray
}
case $2 in
1)
	echo " " > /tmp/upload/ss_log.txt
	http_response "$1"
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	echo_date "                v2ray程序启动" >> /tmp/upload/ss_log.txt
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	check >> /tmp/upload/ss_log.txt 2>&1
	#sh /tmp/upload/t1.sh >> /tmp/upload/ss_log.txt
	echo_date "===================================================================" >> /tmp/upload/ss_log.txt
	echo XU6J03M6 >> /tmp/upload/ss_log.txt
	;;
esac