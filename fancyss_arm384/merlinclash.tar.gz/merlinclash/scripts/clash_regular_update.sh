#!/bin/sh

source /koolshare/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/upload/merlinclash_node_mark.log

LOGFILE=/tmp/upload/merlinclash_log.txt
Regularlog=/tmp/upload/merlinclash_regular.log

yamlname=$merlinclash_yamlsel
#配置文件路径
yamlpath=/koolshare/merlinclash/yaml_use/$yamlname.yaml

filename=/koolshare/merlinclash/yaml_bak/subscription.txt
mcflag=$merlinclash_flag

rm -rf $Regularlog

echo_date "定时订阅进程启动" >> $Regularlog

a=$(ls $filename | wc -l)
if [ $a -gt 0 ]; then
	lines=$(cat $filename | wc -l)
	i=1
	while [ "$i" -le "$lines" ]
	do
		sleep 1s
		line=$(sed -n ''$i'p' "$filename")
		#echo $line
		#echo ""
		name=$(echo $line |grep -o "\"name\".*"|awk -F\" '{print $4}')
		#名字去除.yaml后缀
		name=$(echo $name | awk -F"." '{print $1}')
		link=$(echo $line | grep -o "\"link\".*"|awk -F\" '{print $4}')
		type=$(echo $line | grep -o "\"type\".*"|awk -F\" '{print $4}')
		use=$(echo $line | grep -o "\"use\".*"|awk -F\" '{print $4}')
		ruletype=$(echo $line | grep -o "\"ruletype\".*"|awk -F\" '{print $4}')
		clashtarget=$(echo $line | grep -o "\"clashtarget\".*"|awk -F\" '{print $4}')
		emoji=$(echo $line | grep -o "\"emoji\".*"|awk -F\" '{print $4}')
		udp=$(echo $line | grep -o "\"udp\".*"|awk -F\" '{print $4}')
		appendtype=$(echo $line | grep -o "\"appendtype\".*"|awk -F\" '{print $4}')
		sort=$(echo $line | grep -o "\"sort\".*"|awk -F\" '{print $4}')
		fnd=$(echo $line | grep -o "\"fnd\".*"|awk -F\" '{print $4}')
		include=$(echo $line | grep -o "\"include\".*"|awk -F\" '{print $4}')
		exclude=$(echo $line | grep -o "\"exclude\".*"|awk -F\" '{print $4}')
		scv=$(echo $line | grep -o "\"scv\".*"|awk -F\" '{print $4}')
		tfo=$(echo $line | grep -o "\"tfo\".*"|awk -F\" '{print $4}')
		acltype=$(echo $line | grep -o "\"acltype\".*"|awk -F\" '{print $4}')
		if [ "$mcflag" != "HND" ]; then
			addr=$(echo $line | grep -o "\"addr\".*"|awk -F\" '{print $4}')
			#echo_date "addr=$addr" >> $Regularlog
		else
			customrule=$(echo $line | grep -o "\"customrule\".*"|awk -F\" '{print $4}')
		fi
		#echo_date "name=$name" >> $Regularlog
		#echo_date "link=$link" >> $Regularlog
		#echo_date "type=$type" >> $Regularlog
		#echo_date "use=$use" >> $Regularlog
		#echo_date "ruletype=$ruletype" >> $Regularlog
		#echo_date "acltype=$acltype" >> $Regularlog
		#echo_date "clashtarget=$clashtarget" >> $Regularlog
		#echo_date "emoji=$emoji" >> $Regularlog
		#echo_date "udp=$udp" >> $Regularlog
		#echo_date "appendtype=$appendtype" >> $Regularlog
		#echo_date "sort=$sort" >> $Regularlog
		#echo_date "fnd=$fnd" >> $Regularlog
		#echo_date "include=$include" >> $Regularlog
		#echo_date "exclude=$exclude" >> $Regularlog
		#echo_date "scv=$scv" >> $Regularlog
		#echo_date "tfo=$tfo" >> $Regularlog
		#echo_date "acltype=$acltype" >> $Regularlog
		#echo_date "customrule=$customrule" >> $Regularlog
		#echo_date "" >> $Regularlog
		#根据type类型调用不同订阅方法
		case $type in
		1)
		#	echo "启动方案1"
			/bin/sh /koolshare/scripts/clash_online_yaml.sh "$name" "$type" "$link"
			sleep 3s
			;;
		2)
		#	echo "启动方案2"
			#名字带前缀，先去除前缀
			#name=$(echo $name | awk -F"_" '{print $2}')
			#从左向右截取第一个 _ 后的字符串
			name=$(echo ${name#*_}) 
			/bin/sh /koolshare/scripts/clash_online_yaml2.sh "$name" "$type" "$link" "$ruletype"
			sleep 3s
			;;
		3)
			echo_date "小白一键订阅定时更新" >> $Regularlog
			#名字带前缀，先去除前缀
			#name=$(echo $name | awk -F"_" '{print $2}')
			#从左向右截取第一个 _ 后的字符串
			name=$(echo ${name#*_}) 
			if [ "$mcflag" == "HND" ]; then
				/bin/sh /koolshare/scripts/clash_online_yaml_2.sh "$name" "$type" "$link"
			else
				/bin/sh /koolshare/scripts/clash_online_yaml_2.sh "$name" "$type" "$link" "$addr"
			fi
			sleep 3s
			;;
		4)
			#名字带前缀，先去除前缀
			echo_date "SC/ACL4SSR一键订阅定时更新" >> $Regularlog
			#name=$(echo $name | awk -F"_" '{print $2}')
			#从左向右截取第一个 _ 后的字符串
			name=$(echo ${name#*_}) 
			if [ "$mcflag" == "HND" ]; then
				#echo_date "HND" >> $Regularlog
				/bin/sh /koolshare/scripts/clash_online_yaml4.sh "$name" "$type" "$link" "$clashtarget" "$acltype" "$emoji" "$udp" "$appendtype" "$sort" "$fnd" "$include" "$exclude" "$scv" "$tfo" "$customrule"
			else
				/bin/sh /koolshare/scripts/clash_online_yaml4.sh "$name" "$type" "$link" "$clashtarget" "$acltype" "$emoji" "$udp" "$appendtype" "$sort" "$fnd" "$include" "$exclude" "$scv" "$tfo" "$addr"
			fi
			sleep 3s
			;;
		esac
		let i=i+1
	done
	#订阅后重启clash
	sleep 5s
	echo_date "订阅后重启clash" >> $LOG_FILE
	/bin/sh /koolshare/merlinclash/clashconfig.sh restart
fi


